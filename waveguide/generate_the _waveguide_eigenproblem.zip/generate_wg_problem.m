function nep=generate_wg_problem(varargin)
% Generates the discretization of the waveguide used in 
%
%   "The waveguide eigenvalue problem and the tensor infinite Arnoldi
%   method", Jarlebring, Mele, Runborg
%
% The function returns the matrices in equation (1.5), the discretization
% parameters and a function handle that evaluate M(lambda).
%  
% Usage:   
%
% nep=generate_wg_problem()
%      Generates the default discretization
%
% nep=generate_wg_discretization(nx,nz,wgtype,delta,cayley)
%     Generate a discretization with nx and ny discretization points
%     in x- and y-direction. wgtype is 'tausch' (section 5.1) or
%     'wedge' (section 5.2). delta is an optional parameter
%     that specify this distance from the minimal interior domain
%     and the x-location of the  DtN-operator.  See Remark 2.1. 
%     cayley is a boolean, if cayley=0 the problem (1.5) is considered
%     i.e. without the Cayley transformation, if cayley=1 the problem 
%     (4.3) is considered, i.e. with the Cayley transformation. 
%     See Section 4.1.
%     
%
% Output:
%
%   Function handle
%
%       nep.M is a function handle, nep.M(lambda) evaluate the NEP in lambda
%
%   Matrices
%       nep.A0      nep.A1    nep.A2
%       nep.C10     nep.C11   nep.C12
%       nep.C2T
%
%   Functions involved in the Cayley transformation
%       nep.sP      nep.sM
%
%   Discretization paramenters
%       nep.dm      nep.dp
%       nep.hx      nep.hz
%       nep.nx      nep.nz  nep.n  nep.p
%       nep.Kp      nep.Km
%
%   Auxiliary output for plotting
%       nep.XX      nep.ZZ
%   
% Example: generation of the problem 
% nep=generate_wg_problem(100,101,'tausch',0,false)
% nep=generate_wg_problem(100,101,'wedge',0,true)
%
% Example: testing solutions (tausch)
% nep=generate_wg_problem(100,101,'tausch',0,false);
% load tausch_solutions
% residual=norm(nep.M(lambda)*v)
% %plot the eigenfunction
% v=v(1:nep.nx*nep.nz);
% v=reshape(v,nep.nz,nep.nx);
% imagesc(nep.XX,nep.ZZ,abs(v))
%
% Example: testing solutions (wedge)
% nep=generate_wg_problem(200,201,'wedge',0,false);
% load wedge_solutions
% residual=norm(nep.M(lambda)*v)
% %plot the eigenfunction
% v=v(1:nep.nx*nep.nz);
% v=reshape(v,nep.nz,nep.nx);
% imagesc(nep.XX,nep.ZZ,abs(v))
%
%   Version: 2015-10-19
%
%   Copyright(C) 2015 Giampaolo Mele and Elias Jarlebring    


    
    if length(varargin)==0
        display('default setting')
        varargin={20,21,'tausch',0,false};
    end
    
    
    if(isa(varargin{4},'double')&&(isa(varargin{1},'double'))&&isa(varargin{2},'double')&&(islogical(varargin{5})))
        delta=varargin{4};
        nx=varargin{1};
        nz=varargin{2};
        cayley=varargin{5};
    else
        error('Unknown type')
    end
    
    
    
    if ischar(varargin{3})
        wgtype=varargin{3};
        omega=pi;
        
        if (strcmp(wgtype,'tausch'))
            wg=create_wg('tausch');
            nep.gamma0= -3-1i*pi;     	nep.cgamma0=conj(nep.gamma0);
            Kconst=NaN(3,1);
            x_minus=-delta;   x_plus=2/pi+0.4+delta;
            Kconst(1)=sqrt(2.3)*omega;
            Kconst(2)=sqrt(3)*omega; 
            Kconst(3)=omega;

            % parameters that define the geometry of the waveguide
            % (specified in the Tausch example)
            r1=0;
            r2=2/pi;
            r3=2/pi+0.4;
            s=0.5;
            
            k=@(x,z) Kconst(1)*(x<=r1)+                            ...
              Kconst(3)*(x>=r3)+                            ...
              Kconst(2)*(x<=r2).*(~(x<r1))+                 ...
              Kconst(2)*(~(x<=r2)).*(z>=s).*(~(x>r3))+      ...
              Kconst(3)*(~(x>=r3)).*(~(x<=r2)).*(~(z>=s))   ...
              ;

            % imposing 1-periodicity in the z-direction
            wn=@(x,z) k(x,mod(z,1));

            
            
        elseif (strcmp(wgtype,'wedge'))
            wg=create_wg('wedge');
            nep.gamma0= -2-1i*pi;     	nep.cgamma0=conj(nep.gamma0);
            Kconst=NaN(4,1); 
            x_minus=-1-delta;  x_plus=1+delta;
            Kconst(1)=sqrt(2.3)*omega;
            Kconst(2)=2*sqrt(3)*omega; 
            Kconst(3)=4*sqrt(3)*omega;
            Kconst(4)=omega;
            A = @(x,y)  (x<-1);
            B = @(x,y)  (~(A(x,y))).*(   (y<=-1/2*x) + (y>=1/2*x+1)    );
            C = @(x,y)  (~(A(x,y))).*(~(B(x,y))).*(   (x<=0.5)    + (x>0.5).*(x<1).*(y>=0.4)    );
            D = @(x,y)  (~(A(x,y))).*(~(B(x,y))).*(~(C(x,y)));
            
            % A, B, C and D are indicator functions, it is possible that I did some
            % mistake in building them so I fix it imposing that they can be 0 or 1
            
            A = @(x,y)  A(x,y)~=0;
            B = @(x,y)  B(x,y)~=0;
            C = @(x,y)  C(x,y)~=0;
            D = @(x,y)  D(x,y)~=0;
            


            k=@(x,y)     Kconst(1)*A(x,y)+...
              Kconst(2)*B(x,y)+...
              Kconst(3)*C(x,y)+...
              Kconst(4)*D(x,y);
            
            % imposing 1-periodicity in the z-direction
            wn=@(x,z) k(x,mod(z,1));
                        
        else
            error(['unknown waveguide type: "',wgtype,'"'])
        end
        display(['Using waveguide type "', wgtype,'"'])
    else
        error('Unknown type')
    end
    
    if(mod(nz,2)==0)
        nz=nz+1;
    end
    wn_square = @(x,z) wn(x,z).^2;                      

    
    
    hx=(x_plus-x_minus)/(nx+1);  hz=1/nz;
    XX=linspace(x_minus,x_plus,nx+2);       XXtemp=XX; 			
    ZZ=linspace(0,1,nz+1);                  ZZ=ZZ(2:end);	
    
    XX=XX(2:end-1);
    
    
    ex = ones(nx,1);    ez = ones(nz,1);
    
    Fx = spdiags([ex  4*ex  ex],   -1:1, nx, nx);	Fz = spdiags([ez  4*ez  ez], -1:1, nz, nz);  
    Ex = spdiags([-ex 2*ex -ex],   -1:1, nx, nx);	Ez = spdiags([-ez 2*ez -ez], -1:1, nz, nz);
    Gx = spdiags([ex  0*ex -ex],   -1:1, nx, nx);	Gz = spdiags([ez  0*ez -ez], -1:1, nz, nz);
    
    Dxx     =   -(hz/hx)*(1/6)*kron(Ex,circ(Fz));   
    Dzz     =   -(hx/hz)*(1/6)*kron(Fx,circ(Ez));
    Dz      =   -(hx/12)*kron(Fx,circ(Gz));
    B       =   ((hx*hz)/(4*9))*kron(Fx,circ(Fz));

    display('Computing K-matrix')
    if (strcmp(wgtype,'tausch'))
        [K, KC_up, KC_down]  =   compute_K_Tausch(XX, ZZ,wn_square,Kconst.^2, hx,hz,nx,nz,x_minus,x_plus);
    elseif (strcmp(wgtype,'wedge'))
        [K, KC_up, KC_down]  =   compute_K_wedge(XX, ZZ, wn_square,Kconst.^2, hx,hz,nx,nz,x_minus,x_plus);
        %'nothing'
    end
    nep.K=K;            


    display('Computing A-matrices')
    A0=Dxx+Dzz;  % the term with K will be added later
    A1=2*Dz;
    A2=B;

    display('Computing C1-matrices')

    C10up    =   A0(nz+1:2*nz,1:nz)+KC_up;
    C10down  =   A0((nx-2)*nz+1:(nx-1)*nz,(nx-1)*nz+1:nx*nz)+KC_down;

    e_1=speye(nx);      e_1=e_1(:,1);                
    e_nx=speye(nx);     e_nx=e_nx(:,nx);   

    C10=[kron(e_1,C10up) kron(e_nx,C10down)];
    A0=A0+K;   


    C11up=A1(nz+1:2*nz,1:nz);    C11down=A1((nx-2)*nz+1:(nx-1)*nz,(nx-1)*nz+1:nx*nz);     
    C12up=A2(nz+1:2*nz,1:nz);    C12down=A2((nx-2)*nz+1:(nx-1)*nz,(nx-1)*nz+1:nx*nz);     
    C11=[kron(e_1,C11up) kron(e_nx,C11down)];
    C12=[kron(e_1,C12up) kron(e_nx,C12down)];


    display('Computing C2T')
    
    d0 = -3/(2*hx);   d1 = 2/(hx);  d2 = -1/(2*hx);

    dm = sparse(1,nx);  dm(1)=d1;       dm(2)=d2;       C2Tm = kron(dm,speye(nz));
    dp = sparse(1,nx);  dp(nx)=d1;      dp(nx-1)=d2;    C2Tp = kron(dp,speye(nz));

    C2T=[C2Tm; C2Tp];

    XX=XXtemp;
    
    % MATRICES-PARAMENTERS OUTPUT
    nep.A0=A0;      nep.A1=A1;    nep.A2=A2;
    nep.C10=C10;    nep.C11=C11;  nep.C12=C12;
    nep.C2T=C2T;
    nep.XX=XX;      nep.ZZ=ZZ;
    nep.dm=dm;      nep.dp=dp;
    nep.hx=hx;      nep.hz=hz;
    nep.nx=nx;      nep.nz=nz;
    nep.n=nx*nz+2*nz;
    
    p=(nz-1)/2;
    nep.p=p;
    
    if (strcmp(wgtype,'tausch'))
        x_minus=0;   x_plus=2/pi+0.4;
    elseif (strcmp(wgtype,'wedge'))
        x_minus=-1;   x_plus=1;	
    end
    
    			
    xa=x_minus-delta;       xb=x_plus+delta;   
    Km=wg(xa-2,1/2);        Kp=wg(xb+2,1/2);



    % Computation of the Fourier operator (and the inverse)
    %bb=exp(-2i*pi*((1:nz)-1)*(-p)/nz).';  % scaling to do after FFT
    %R=@(x) flipud(bb.*fft(x));

    %bbinv=1./bb; % scaling to do before inverse FFT
    %Rinv=@(x) ifft(bbinv.*flipud(x));

    % definition of Fourier operators for matrices
    bb=exp(-2i*pi*((1:nz)-1)*(-p)/nz).';  % scaling to do after FFT
    nep.R_m=@(X) flipud((bb*ones(size(X,2),1)').*fft(X));


    bbinv=1./bb; % scaling to do before inverse FFT
    nep.Rinv_m=@(X) ifft((bbinv*ones(size(X,2),1)').*flipud(X));

    % FUNCTIONS RELATED TO THE DtN-map
    betaP=@(gamma) (( gamma + 2*pi*1i*(-p:p) ) + 1i*Kp).*(( gamma + 2*pi*1i*(-p:p) ) - 1i*Kp);
    betaM=@(gamma) (( gamma + 2*pi*1i*(-p:p) ) + 1i*Km).*(( gamma + 2*pi*1i*(-p:p) ) - 1i*Km);    
    
    sgP(1,1:nz)=sign(imag(betaP(-1-1i)));    
    sgM(1,1:nz)=sign(imag(betaM(-1-1i)));    
    
    nep.sP=@(gamma) 1i*sgP.*sqrt(betaP(gamma))+d0;
    nep.sM=@(gamma) 1i*sgM.*sqrt(betaM(gamma))+d0;
    
    if cayley==true
        nep.sP=@(lambda) nep.sP((nep.gamma0+lambda*nep.cgamma0)./(1-lambda)).*(1-lambda);
        nep.sM=@(lambda) nep.sM((nep.gamma0+lambda*nep.cgamma0)./(1-lambda)).*(1-lambda);       
    end
    
    nep.cayley=cayley;
    nep.M=@(lambda) M( lambda, nep );
    nep.Kp=Kp;  nep.Km=Km;

    
    
end


function [ Mval ] = M( lambda, nep )
%M evaluate M (before the Cayley transformation) in lambda
%   Detailed explanation goes here

if nep.cayley==true
    M1=(1-lambda)^2*nep.A0+(nep.gamma0+lambda*nep.cgamma0)*(1-lambda)*nep.A1+(nep.gamma0+lambda*nep.cgamma0)^2*nep.A2;
    M2=(1-lambda)^2*nep.C10+(nep.gamma0+lambda*nep.cgamma0)*(1-lambda)*nep.C11+(nep.gamma0+lambda*nep.cgamma0)^2*nep.C12;
    M3=(1-lambda)*nep.C2T;
else
    M1=nep.A0+lambda*nep.A1+lambda^2*nep.A2;
    M2=nep.C10+lambda*nep.C11+lambda^2*nep.C12;
    M3=nep.C2T;    
end

GammaP=nep.sP(lambda);
GammaM=nep.sM(lambda);

GammaP=nep.R_m(diag(GammaP))*nep.Rinv_m(eye(nep.nz));
GammaM=nep.R_m(diag(GammaM))*nep.Rinv_m(eye(nep.nz));

M4=[ GammaM, sparse(nep.nz,nep.nz); sparse(nep.nz,nep.nz), GammaP ];
M4=sparse(M4);


Mval=[M1,M2;M3,M4];

end

function k=create_wg(str)
    

    if(strcmpi(str,'tausch'))
 


        % PIECEWISE CONSTANT FUNCTION THAT DEFINES THE TAUSCH WAVEGUIDE 

        % parameter that define the magnituto of K(x,y)
        omega=pi;
        K1=sqrt(2.3)*omega;
        K2=sqrt(3)*omega; 
        K3=omega;


        % parameters that define the geometry of the waveguide
        % (setted as in the Tausch example)
        r1=0;
        r2=2/pi;
        r3=2/pi+0.4;
        s=0.5;

        k=@(x,z) K1*(x<=r1)+                            ...
                 K3*(x>=r3)+                            ...
                 K2*(x<=r2).*(~(x<r1))+                 ...
                 K2*(~(x<=r2)).*(z>=s).*(~(x>r3))+      ...
                 K3*(~(x>=r3)).*(~(x<=r2)).*(~(z>=s))   ...
                 ;

        % imposing 1-periodicity in the z-direction
        k=@(x,z) k(x,mod(z,1));
        
            
    elseif(strcmpi(str,'wedge'))
        omega=pi;
        K1=sqrt(2.3)*omega;
        K2=2*sqrt(3)*omega; 
        K3=4*sqrt(3)*omega;
        K4=omega;

        A = @(x,y)  (x<-1);
        B = @(x,y)  (~(A(x,y))).*(   (y<=-1/2*x) + (y>=1/2*x+1)    );
        C = @(x,y)  (~(A(x,y))).*(~(B(x,y))).*(   (x<=0.5)    + (x>0.5).*(x<1).*(y>=0.4)    );
        D = @(x,y)  (~(A(x,y))).*(~(B(x,y))).*(~(C(x,y)));

        % A, B, C and D are indicator functions, it is possible that I did some
        % mistake in building them so I fix it imposing that they can be 0 or 1

        A = @(x,y)  A(x,y)~=0;
        B = @(x,y)  B(x,y)~=0;
        C = @(x,y)  C(x,y)~=0;
        D = @(x,y)  D(x,y)~=0;



        k=@(x,y)     K1*A(x,y)+...
                     K2*B(x,y)+...
                     K3*C(x,y)+...
                     K4*D(x,y);

        % imposing 1-periodicity in the z-direction
        k=@(x,z) k(x,mod(z,1));
        

    else
        fprintf('\n Invalid choise! Waveguide setted as 0-function \n');
        k=0;
    end

		 

 
    
end



function [ A ] = circ( A )
    A(1,end)=A(2,1);
    A(end,1)=A(end-1,end);
end
    
% 
% 
% function [K, KC_up, KC_down]  =   compute_K_Tausch(XX, ZZ,wg_square,Kconst.^2, hx,hz,nx,nz,x_minus,x_plus)
%     K=0;
%     KC_up=0;
%     KC_down=0;
% end



function [K, KC_up, KC_down]=compute_K_Tausch(xv, yv, kvp,Kconst, hx,hy,Nx,Ny,xa,xb)
% Computes the FEM-matrix corresponding to a term K(x,y) u(x,y)
% where K(x,y) is piecewise constant where constant values are specified
% in the vector Kconst 
%
% OUTPUT
% K is the matrix that defines the problem in the interior points
% K_up is the matrix that defines the problem at the left boundary x_-
% K_down is the matrix that defines the problem at the right boundary x_+
% K_up and K_down are needed to define the matrix C_0


	% parameters that define the geometry of the waveguide
	% (setted as in the Tausch example)
	r1=0;
	r2=2/pi;
	r3=2/pi+0.4;
	s=0.5;



    xv=[xa xv xb];  Nx=Nx+2;

    % AUXILIARY MATRICES
    ex = ones(Nx,1);    ey = ones(Ny,1);
    M1x = spdiags([ex 4*ex ex], -1:1, Nx, Nx);
    M1y = spdiags([ey 4*ey ey], -1:1, Ny, Ny);  
    M1yp=circ(M1y); 

    B  =   ((hx*hy)/(4*9))*kron(M1x,M1yp);
    
        
    KKint=zeros(length(yv),length(xv));  % elements which must be
                                         % "manually" computed with integrals
                                       
    % elements associated with a corresponding kvp-constant value
    KK=zeros(length(yv),length(xv),length(Kconst)); 
    XX=ones(length(yv),1)*xv;
    YY=yv'*ones(1,length(xv));    
    Kkv=kvp(XX,YY);
    z=(-1:1)';
    nearby=[kron(z,ones(size(z))),kron(ones(size(z)),z)];
    % Compute KK (zeros where kv(xj,yj,jj)=)
    for i=1:length(xv)
        for j=1:length(yv)
            Kv=Kkv(j,i);
            are_equal=1;
            for jj=1:size(nearby,1)
                i2=i+nearby(jj,2);
                j2=j+nearby(jj,1);            
                
                if (i2>0 && i2<=Nx)

                    j2mod=mod(j2-1,Ny)+1;
                    
                    if (abs(Kv-Kkv(j2mod,i2))>eps)                        
                        are_equal=0;
                    end
                end
            end
            KKint(j,i)=~are_equal;
            for jj=1:length(Kconst) 
                if (abs(Kconst(jj)-Kv)<eps)
                    KK(j,i,jj)=are_equal;
                end
            end
        end
    end
    
    % Construct those rows in K which can be precomputed (and
    % stored in KK).
    K=sparse(length(xv)*length(yv),length(xv)*length(yv));
    for i=1:length(Kconst)
        
        DD=diag(sparse(reshape(KK(:,:,i),Nx*Ny,1)));
        K=K+DD*B*Kconst(i);

    end

    
    
    % form bilinear form products between all basis functions
    j=NaN;

    ll=length(find(KKint));
    i_indx=zeros(ll,1);
    j_indx=zeros(ll,1);    
    kval_indx=zeros(ll,1);    
    count=1;
    for i=1:length(xv)
        
        jv=find(KKint(:,i))'; % Only do the (i,j) elements which are
                              % marked to be integrated (KKint)
        for j=jv
            % basis function 1: center xv(i),yv(j)
            for i2=max(1,i-1):min(i+1,Nx)
                for j2=j-1:j+1
                    
                    xvi2=xv(1)+hx*(i2-1); 
                    yvj2=yv(1)+hy*(j2-1); % since we need to go
                                          % outside of the domain                   
                    j2mod=mod(j2-1,Ny)+1;
                    
                    % Compute corners of non-zero part of basis functions
                    % basis function 1:
                    za1=(xv(i)-hx)+1i*(yv(j)-hy);
                    zb1=(xv(i)+hx)+1i*(yv(j)+hy);

                    % basis function 2:
                    za2=(xvi2-hx)+1i*(yvj2-hy);
                    zb2=(xvi2+hx)+1i*(yvj2+hy);
                    
                    % compute intersection
                    xx=range_intersection2([real(za1),real(zb1)],[real(za2),real(zb2)]);
                    xmin=xx(1); xmax=xx(2);
                    xx=range_intersection2([imag(za1),imag(zb1)],[imag(za2),imag(zb2)]);
                    ymin=xx(1); ymax=xx(2);
                        

                    k1=kvp(xmin,ymin);
                    k2=kvp(xmin,ymax);
                    k3=kvp(xmax,ymin);
                    k4=kvp(xmax,ymax);
                    
                    if (~(k1==k2 && k2==k3 && k3==k4) )
                        
                        % function that will be integrated
                        intfun=@(x,y) bilinfun2_periodic(x+1i*y,za1,zb1,0).*bilinfun2_periodic(x+1i*y,za2,zb2,0);
                        
                        
                        
                        % DIVIDE THE SQUARE IN FOUR SQUARES WHERE K IS
                        % CONSTANT. COMPUTE THE INTEGRALS IN THE SUBSQUARES
                        % AND SUM.
                        xmed=mean([xmin,xmax]);     ymed=mean([ymin,ymax]);
                        
                        
                        
                        % first rectangle [xmin xmed]x[ymin ymed]                                  
                        kk1=integral_on_rectangle_tausch(intfun, xmin,xmed,ymin,ymed, i, j, i2,j2, kvp, hx, hy, r1, r2, r3, s);
                            
                        % second rectangle [xmed xmax]x[ymin ymed]
                        kk2=integral_on_rectangle_tausch(intfun, xmed,xmax,ymin,ymed, i, j, i2,j2, kvp, hx, hy, r1, r2, r3, s);
                            
                            
                        % third rectangle [xmin xmed]x[ymed ymax]
                        kk3=integral_on_rectangle_tausch(intfun, xmin,xmed,ymed,ymax, i, j, i2,j2, kvp, hx, hy, r1, r2, r3, s);
                            
                        % fourth rectangle [xmed xmax]x[ymed ymax]
                        kk4=integral_on_rectangle_tausch(intfun, xmed,xmax,ymed,ymax, i, j, i2,j2, kvp, hx, hy, r1, r2, r3, s);
                         
                            
                        % sum all the pieces    
                        kk=kk1+kk2+kk3+kk4;    
                                                                                                                                                               
                    else

                        kk=kvp(mean([xmin,xmax]),mean([ymin,ymax]))*coeff_B( i,j,i2,j2 )*(hx*hy)/(4*9);

                    
                    end
                    
                    % store the matrix Ktilde (see notes) in three vectors
                    i_indx(count)=j+Ny*(i-1);
                    j_indx(count)=j2mod+Ny*(i2-1);
                    kval_indx(count)=kk;
                    count=count+1;
                end
            end
        end
    end    
    
    % build the sparse matrix that defines Ktilde
    Ktilde=sparse(i_indx,j_indx,kval_indx,Nx*Ny,Nx*Ny,count);
    K=K+Ktilde;
    
    
    % REMOVE THE FIRST AND THE LAST BLOCK-ROW FROM THE MATRIX K
    % the block (i,j) of the matrix is compute with the general formula
    % [ (i-1)*nz+1:i*nz, (j-1)*nz+1:j*nz ]
    
    K=K(Ny+1:(Nx-1)*Ny,:);
    
    
    
    % SELECTING THE MATRICES THAT WILL BE USED TO COMPUTE C
    KC_up       =   K(1:Ny,1:Ny);
    KC_down     =   K(end-Ny+1:end,end-Ny+1:end);
    
       
    % REMOVING THE FIRST AND THE LAST BLOCK-COLOUMNS FROM K
    K=K(:,Ny+1:end-Ny);
    
    
end


function kk = integral_on_rectangle_tausch(intfun, xx1,xx2,yy1,yy2, i, j, i2,j2, kvp, hx, hy, r1, r2, r3, s)
%integral_on_square compute the integral on an element [xx1,xx2]x[yy1,yy2]
%   xx1,xx2,yy1,yy2 coordinates of the element
%   the function that we are integrating is 
%   phi_(i,j) (x,y) phi_(i2,j2)(x,y) kvp(x,y)
%   hx and hy are the discretization parameters
%
%
%   The idea is to split the integrals in such way that everytime we have
%   to integrate a polynomial function
%
%
%
%   THE WAVEGUIDE HAS THE FOLLOWING GEOMETRY
%
%   ____________________________________________________
%           |                        |           |
%           |                        |           |
%           |                        |           |
%           |                        |           |
%           |             ___________| s         |
%           |             |                      |
%           |             |                      |
%           |             |                      |
%   ________|_____________|______________________|______
% 
%          r1             r2                    r3
%
%

% the function that will be integrated is intfun

    if  ( (r1>xx1)   &&  (r1<xx2)  )
    
        % split the integral in
        % [xx1 r1]x[yy1 yy2] 
        % [r1 xx2]x[yy1 yy2]
        
        
        Kw1_val=kvp(mean([xx1,r1]),mean([yy1,yy2]));
        Kw2_val=kvp(mean([r1,xx2]),mean([yy1,yy2]));
        
        w1=my_num_int( intfun, xx1, r1, yy1, yy2 );
        w2=my_num_int( intfun, r1, xx2, yy1, yy2 );
        
        kk=Kw1_val*w1+Kw2_val*w2;
    
    elseif (   (yy2<s) && (r2>xx1)   &&  (r2<xx2) )
        
        % split the integral in
        % [xx1 r2]x[yy1 yy2] 
        % [r2 xx2]x[yy1 yy2]
        
        Kw1_val=kvp(mean([xx1,r2]),mean([yy1,yy2]));
        Kw2_val=kvp(mean([r2,xx2]),mean([yy1,yy2]));
        
        w1=my_num_int( intfun, xx1, r2, yy1, yy2 );
        w2=my_num_int( intfun, r2, xx2, yy1, yy2 );
        
        kk=Kw1_val*w1+Kw2_val*w2;
        
    elseif (   (yy1>s) && (r3>xx1)   &&  (r3<xx2) )
        
        % split the integral in
        % [xx1 r3]x[yy1 yy2] 
        % [r3 xx2]x[yy1 yy2]
        
        Kw1_val=kvp(mean([xx1,r3]),mean([yy1,yy2]));
        Kw2_val=kvp(mean([r3,xx2]),mean([yy1,yy2]));
        
        w1=my_num_int( intfun, xx1, r3, yy1, yy2 );
        w2=my_num_int( intfun, r3, xx2, yy1, yy2 );
        
        kk=Kw1_val*w1+Kw2_val*w2;
        
    
    elseif (  (yy1<s) && (yy2>s)  )
    
        if ( (r2>xx1)   &&  (r2<xx2) )
        
            % split the integral in
            % [xx1 r2]x[yy1 s]
            % [r2 xx2]x[yy1 s]
            % [xx1 r2]x[s yy2]
            % [r2 xx2]x[s yy2]

            Kw1_val=kvp(mean([xx1,r2]),mean([yy1,s]));
            Kw2_val=kvp(mean([r2,xx2]),mean([yy1,s]));
            Kw3_val=kvp(mean([xx1,r2]),mean([s,yy2]));
            Kw4_val=kvp(mean([r2,xx2]),mean([s,yy2]));
            
            w1=my_num_int( intfun, xx1, r2, yy1, s );
            w2=my_num_int( intfun, r2, xx2, yy1, s );
            w3=my_num_int( intfun, xx1, r2, s, yy2 );
            w4=my_num_int( intfun, r2, xx2, s, yy2 );
            
            kk=Kw1_val*w1+Kw2_val*w2+Kw3_val*w3+Kw4_val*w4;

        
        elseif ( (r3>xx1)   &&  (r3<xx2) )
                      
            % split the integral in
            % [xx1 r3]x[yy1 s]
            % [r3 xx2]x[yy1 s]
            % [xx1 r3]x[s yy2]
            % [r3 xx2]x[s yy2]
            
            Kw1_val=kvp(mean([xx1,r3]),mean([yy1,s]));
            Kw2_val=kvp(mean([r3,xx2]),mean([yy1,s]));
            Kw3_val=kvp(mean([xx1,r3]),mean([s,yy2]));
            Kw4_val=kvp(mean([r3,xx2]),mean([s,yy2]));
            
            w1=my_num_int( intfun, xx1, r3, yy1, s );
            w2=my_num_int( intfun, r3, xx2, yy1, s );
            w3=my_num_int( intfun, xx1, r3, s, yy2 );
            w4=my_num_int( intfun, r3, xx2, s, yy2 );
            
            kk=Kw1_val*w1+Kw2_val*w2+Kw3_val*w3+Kw4_val*w4;
            
        
        else
        
            % split the integral in
            % [xx1 xx2]x[yy1 s]
            % [xx1 xx2]x[s yy2]
            
            Kw1_val=kvp(mean([xx1,xx2]),mean([yy1,s]));
            Kw2_val=kvp(mean([xx1,xx2]),mean([s,yy2]));
        
            w1=my_num_int( intfun, xx1, xx2, yy1, s );
            w2=my_num_int( intfun, xx1, xx2, s, yy2 );
            
            kk=Kw1_val*w1+Kw2_val*w2;

        
        end
    
    else    
        
        % the rectangle (element) does not contain discontinuities f the
        % function kv than we can use the previous formula that is to
        % perform the quadrature without splitting the domain since we are
        % integrating a polynomial function        
        
        kk_val=kvp(mean([xx1,xx2]),mean([yy1,yy2]));
        kk=kk_val*coeff_integral( i,j,i2,j2 )*(hx*hy)/(4*9);

    end
    
    
end

function v=bilinfun2_periodic(xz,zz1,zz2,diffr,varargin)
% Constructs a bilinear basis function on the square defined by 
% (real(zz1),imag(zz1)) and (real(zz2),imag(zz2))
% and evaluates it in points defined by xz.
%
% The basis function is constructed such that it is periodic in
% the y-direction with period ymax=1.
% 
% if diffr=0 it returns function values
% if diffr=1 it returns x-derivatives
% if diffr=2 it returns y-derivatives
%
% vv=bilinfun2(1.5+1.5i,1+1i,2+2i,0)
%
% XX=ones(100,1)*linspace(0,2,100);
% YY=linspace(0,2,size(XX,1))'*ones(1,size(XX,2));
% ZZ=XX+1i*YY;
% CC=bilinfun2(ZZ,1+1i,2+2i,0,1);
% surf(XX,YY,CC*(1+eps))



if (length(varargin)>0)
    quadrant=varargin{1};
else
    % recursive call for all four quadrants:
    v=  bilinfun2_periodic(xz,zz1,zz2,diffr,1);
    v=v+bilinfun2_periodic(xz,zz1,zz2,diffr,2);
    v=v+bilinfun2_periodic(xz,zz1,zz2,diffr,3);
    v=v+bilinfun2_periodic(xz,zz1,zz2,diffr,4);
    return
end


%z1=mean([zz1,zz2]);
z1=(zz1+zz2)/2; % seems faster and equivalent to the previuos line


hx=abs(real(z1-zz1));
hy=abs(imag(z1-zz1));

% z1 = point where basis function is 1
% z2 = opposite diagonal to the point where the function is 1
% r0 = rectangle [x,y,w,h] for this quadrant

switch quadrant
  case 1
      z2=z1+(hx+hy*1i);
      r0=[real(z1),imag(z1),hx,hy];
  case 2
      z2=z1+(-hx+hy*1i);
      r0=[real(z1)-hx,imag(z1),hx,hy];
  case 3
      z2=z1+(-hx-hy*1i);
      r0=[real(z1)-hx,imag(z1)-hy,hx,hy];
  case 4
      z2=z1+(hx-hy*1i);
      r0=[real(z1),imag(z1)-hy,hx,hy];
end



% construct matrix which is for points in xz that are inside the currently
% considered rectangle:
II0=((real(xz)>=r0(1)) & (real(xz)<(r0(1)+r0(3))) & ...
    (imag(xz)>=r0(2)) & (imag(xz)<(r0(2)+r0(4))) );
if (0) % It is sometimes faster to work with sparse indexing instead
    II0=sparse(II0);
end 

% Impose periodicity:
% Essentially, move all xz +/- 0.5 and rectangle in y-direction and
% take modulus 1. If modified points are in new rectangle and not
% old rectangle, move the corresponding xz points.
if (r0(2)<=0)
    shift=0.5; % this will not work if the basis function is too
               % large in y-direction
else
    shift=-0.5;    
end
imxmod=mod(imag(xz)+shift,1);
r0mod=[r0(1), mod(r0(2)+shift,1), r0(3), r0(4)];
II1=((real(xz)>=r0(1)) & (real(xz)<(r0(1)+r0(3))) & ...
    (imxmod>=r0mod(2)) & (imxmod<(r0mod(2)+r0mod(4))) );
II1 = II1 & (~II0); % points to modified
xz(II1)=real(xz(II1))+1i*(imxmod(II1)-shift);
II0 = II1 | II0; % II1 points will also have non-zero contribution

% interpolation: with points z1 and z2:
AA=[1, real(z1), imag(z1), real(z1)*imag(z1)
    1, real(z2), imag(z1), real(z2)*imag(z1)
    1, real(z1), imag(z2), real(z1)*imag(z2)
    1, real(z2), imag(z2), real(z2)*imag(z2)];
cc=AA\eye(4,1);


% compute the function value or derivatives in corresponding points
rxz=II0.*real(xz);
ixz=II0.*imag(xz);
switch diffr
  case 0 % function value
    %v=II.*(cc(1)+cc(2)*real(xz)+cc(3)*imag(xz)+cc(4)*real(xz).*(II0.*imag(xz)));
    v=cc(1)*II0+cc(2)*rxz+cc(3)*ixz+cc(4)*(rxz.*ixz);
  case 1 % x-derivative
    %v=II0.*(cc(2)+cc(4)*imag(xz));    
    v=cc(2)*II0+cc(4)*ixz;
  case 2 % y-derivative
    v=cc(3)*II0+cc(4)*rxz;
end
end




function [ res ] = my_num_int( F, xmin,xmax,ymin,ymax )
%MY_NUM_INT quadrature formulas in a square [xmin xmax]x[ymin ymax]
%   quadrature formulas of degree 5


% change of variables
Nphi = @(t) ((xmin+xmax)/2)+t*((xmax-xmin)/2);
Npsi = @(s) ((ymin+ymax)/2)+s*((ymax-ymin)/2);

FF = @(t,s) F(Nphi(t),Npsi(s));




% formula 1, degree 5
% P=sqrt(3/5);
% 
% W1=64/81;
% W2=25/81;
% W3=40/81;
% 
% 
% res= W2*FF(-P,-P)   +W3*FF(0,-P)    +W2*FF(P,-P) + ...
%      W3*FF(-P,0)    +W1*FF(0,0)     +W3*FF(P,0)  + ...
%      W2*FF(-P,P)    +W3*FF(0,P)     +W2*FF(P,P);     






% formula 1, degree 5
P=sqrt(1/3);
res= FF(P,P)+FF(-P,P)+FF(P,-P)+FF(-P,-P);

res=res*(ymax-ymin)*(xmax-xmin);
res=res/4;

end




function [K, KC_up, KC_down]=compute_K_wedge(xv, yv, kvp,Kconst, hx,hy,Nx,Ny,xa,xb)
% Computes the FEM-matrix corresponding to a term k(x,y) u(x,y)
% where k is piecewise constant where constant values are specified
% in the vector Kconst 
%
% OUTPUT
% K is the matrix that defines the problem in the interior points
% K_up is the matrix that defines the problem at the left boundary x_-
% K_down is the matrix that defines the problem at the right boundary x_+
% K_up and K_down are needed to define the matrix C_0




    xv=[xa xv xb];  Nx=Nx+2;

    % AUXILIARY MATRICES
    ex = ones(Nx,1);    ey = ones(Ny,1);
    M1x = spdiags([ex 4*ex ex], -1:1, Nx, Nx);
    M1y = spdiags([ey 4*ey ey], -1:1, Ny, Ny);  
    M1yp=circ(M1y); 

    B  =   ((hx*hy)/(4*9))*kron(M1x,M1yp);
    
        
    KKint=zeros(length(yv),length(xv));  % elements which must be
                                         % "manually" computed with integrals
                                       
    % elements associated with a corresponding kvp-constant value
    KK=zeros(length(yv),length(xv),length(Kconst)); 
    XX=ones(length(yv),1)*xv;
    YY=yv'*ones(1,length(xv));    
    Kkv=kvp(XX,YY);
    z=(-1:1)';
    nearby=[kron(z,ones(size(z))),kron(ones(size(z)),z)];
    % Compute KK (zeros where kv(xj,yj,jj)=)
    for i=1:length(xv)
        for j=1:length(yv)
            Kv=Kkv(j,i);
            are_equal=1;
            for jj=1:size(nearby,1)
                i2=i+nearby(jj,2);
                j2=j+nearby(jj,1);            
                
                if (i2>0 && i2<=Nx)

                    j2mod=mod(j2-1,Ny)+1;
                    
                    if (abs(Kv-Kkv(j2mod,i2))>eps)                        
                        are_equal=0;
                    end
                end
            end
            KKint(j,i)=~are_equal;
            for jj=1:length(Kconst) 
                if (abs(Kconst(jj)-Kv)<eps)
                    KK(j,i,jj)=are_equal;
                end
            end
        end
    end
    
    % Construct those rows in K which can be precomputed (and
    % stored in KK).
    K=sparse(length(xv)*length(yv),length(xv)*length(yv));
    for i=1:length(Kconst)
        
        DD=diag(sparse(reshape(KK(:,:,i),Nx*Ny,1)));
        K=K+DD*B*Kconst(i);

    end

    
    % form bilinear form products between all basis functions
    j=NaN;

    ll=length(find(KKint));
    i_indx=zeros(ll,1);
    j_indx=zeros(ll,1);    
    kval_indx=zeros(ll,1);    
    count=1;
    for i=1:length(xv)
        jv=find(KKint(:,i))'; % Only do the (i,j) elements which are
                              % marked to be integrated (KKint)
        for j=jv
            % basis function 1: center xv(i),yv(j)
            for i2=max(1,i-1):min(i+1,Nx)
                for j2=j-1:j+1
                    
                    xvi2=xv(1)+hx*(i2-1); 
                    yvj2=yv(1)+hy*(j2-1); % since we need to go
                                          % outside of the domain                   
                    j2mod=mod(j2-1,Ny)+1;
                    
                    % Compute corners of non-zero part of basis functions
                    %xmin,xmax,ymin,ymax basis function 1:
                    za1=(xv(i)-hx)+1i*(yv(j)-hy);
                    zb1=(xv(i)+hx)+1i*(yv(j)+hy);

                    % basis function 2:
                    za2=(xvi2-hx)+1i*(yvj2-hy);
                    zb2=(xvi2+hx)+1i*(yvj2+hy);
                    
                    % compute intersection
                    xx=range_intersection2([real(za1),real(zb1)],[real(za2),real(zb2)]);
                    xmin=xx(1); xmax=xx(2);
                    xx=range_intersection2([imag(za1),imag(zb1)],[imag(za2),imag(zb2)]);
                    ymin=xx(1); ymax=xx(2);
                        

                    k1=kvp(xmin,ymin);
                    k2=kvp(xmin,ymax);
                    k3=kvp(xmax,ymin);
                    k4=kvp(xmax,ymax);

                    if (~(k1==k2 && k2==k3 && k3==k4) )
                        
                        % function that will be integrated
                        intfun=@(x,y) bilinfun2_periodic(x+1i*y,za1,zb1,0).*bilinfun2_periodic(x+1i*y,za2,zb2,0);
                        
                        
                        
                        % DIVIDE THE SQUARE IN FOUR SQUARES WHERE K IS
                        % CONSTANT. COMPUTE THE INTEGRALS IN THE SUBSQUARES
                        % AND SUM.
                        xmed=mean([xmin,xmax]);     ymed=mean([ymin,ymax]);
                        
                        

                        
                        % first rectangle [xmin xmed]x[ymin ymed]                                  
                        kk1=integral_on_rectangle_wedge(intfun, xmin,xmed,ymin,ymed, kvp);
                            
                        % second rectangle [xmed xmax]x[ymin ymed]
                        kk2=integral_on_rectangle_wedge(intfun, xmed,xmax,ymin,ymed, kvp);
                            
                        % third rectangle [xmin xmed]x[ymed ymax]
                        kk3=integral_on_rectangle_wedge(intfun, xmin,xmed,ymed,ymax, kvp);
                                                    
                        % forth rectangle [xmin xmed]x[ymed ymax]
                        kk4=integral_on_rectangle_wedge(intfun, xmed, xmax,ymed,ymax, kvp);

%   
%                         xmed=xmed+sqrt(eps);
%                         
%                         % first rectangle [xmin xmed]x[ymin ymed]                                  
%                         kk1b=integral_on_rectangle_wedge(intfun, xmin,xmed,ymin,ymed, kvp);
%                             
%                         % second rectangle [xmed xmax]x[ymin ymed]
%                         kk2b=integral_on_rectangle_wedge(intfun, xmed,xmax,ymin,ymed, kvp);
%                             
%                         % third rectangle [xmin xmed]x[ymed ymax]
%                         kk3b=integral_on_rectangle_wedge(intfun, xmin,xmed,ymed,ymax, kvp);
%                                                     
%                         % forth rectangle [xmin xmed]x[ymed ymax]
%                         kk4b=integral_on_rectangle_wedge(intfun, xmed, xmax,ymed,ymax, kvp);
%                         
%                         
%                         stol=1.e-5;
%                         if(norm(kk1-kk1b)>stol)
%                             keyboard
%                         end
%                         if(norm(kk2-kk2b)>stol)
%                             keyboard
%                         end
%                         if(norm(kk3-kk3b)>stol)
%                             keyboard
%                         end
%                         if(norm(kk4-kk4b)>stol)
%                             keyboard
%                         end
                               
                        
                        % sum all the pieces    
                        kk=kk1+kk2+kk3+kk4;    
                                                                                                                                                               
                    else

                        kk=kvp(mean([xmin,xmax]),mean([ymin,ymax]))*coeff_B( i,j,i2,j2 )*(hx*hy)/(4*9);

                    
                    end
                    
                    % store the matrix Ktilde (see notes) in three vectors
                    i_indx(count)=j+Ny*(i-1);
                    j_indx(count)=j2mod+Ny*(i2-1);
                    kval_indx(count)=kk;
                    count=count+1;
                end
            end
        end
    end    
    
    % build the sparse matrix that defines Ktilde
    Ktilde=sparse(i_indx,j_indx,kval_indx,Nx*Ny,Nx*Ny,count);
    K=K+Ktilde;
    
    
    % REMOVE THE FIRST AND THE LAST BLOCK-ROW FROM THE MATRIX K
    % the block (i,j) of the matrix is compute with the general formula
    % [ (i-1)*nz+1:i*nz, (j-1)*nz+1:j*nz ]
    
    K=K(Ny+1:(Nx-1)*Ny,:);
    
    
    
    % SELECTING THE MATRICES THAT WILL BE USED TO COMPUTE C
    KC_up       =   K(1:Ny,1:Ny);
    KC_down     =   K(end-Ny+1:end,end-Ny+1:end);
    
       
    % REMOVING THE FIRST AND THE LAST BLOCK-COLOUMNS FROM K
    K=K(:,Ny+1:end-Ny);
    
    
end


function kk = integral_on_rectangle_wedge(intfun, xx1,xx2,yy1,yy2, kvp)
%integral_on_square compute the integral on an ELEMENT [xx1,xx2]x[yy1,yy2]
%   xx1,xx2,yy1,yy2 coordinates of the element
%   the function that we are integrating is 
%   phi_(i,j) (x,y) phi_(i2,j2)(x,y) kvp(x,y)
%   hx and hy are the discretization parameters
%
%
%   The idea is to split the integrals in such way that everytime we have
%   to integrate a polynomial function
%
% THE WAVEGUIDE THAT WE ARE ANALYSING IS
%  
% _____________________________________________________________
%         |             /                          |
%         |          /                             |
%         |       /                                |
%         |    /                                   |
%    0.5  | /                                      |
%         | \                                      |
%         |     \                         _________|  0.4
%         |        \                     |
%         |           \                  |
%         |              \               |
% ________|______________________________|______________________             
%         -1              0             0.5         1
% 
%         
%
%   THE TECNICAL THING IS TO CONSIDER THE DIFFERENT CASE_S: HOW THE
%   DISCONTINUITIES LINES CAN CUT THE ELEMENT?
%
%   We call BOTTOM LINE y=-x/2
%           UPPER  LINE y=x/2+1
%
%   It is clear which lines we are speaking about.
%   So we diviive the elements in pieces using triangles, quadrilaterals
%   and rectangules in such way that kvp is constant and so
%   everytime we integrate a polynomial
%   function. Then we can use quadrature formulas.
         
        

%keyboard
if((xx2<=-1)||(xx1>=1))
    
    % the rectangle (element) does not contain discontinuities so the 
    % function kv is a polynomail of second degree and then we can
    % perform a quadrature

    kk_val=kvp(mean([xx1,xx2]),mean([yy1,yy2]));
    w=rectangle_quadrature( intfun, xx1,xx2,yy1,yy2 );
    kk=kk_val*w;
        
        
%if the diagonal line cut the element
elseif ( (xx1<-1) && (xx2>-1) )
    % the vertical line x=-1 cut the element. Then split the
    % integral
        
    % split the integral in
    % [xx1 -1]x[yy1 yy2] 
    % [-1 xx2]x[yy1 yy2]
            
    kk = integral_on_rectangle_wedge(intfun, xx1,-1,yy1,yy2, kvp)+    ...
         integral_on_rectangle_wedge(intfun, -1,xx2,yy1,yy2, kvp);
        
% BOTTON LINE together with UPPER LINE may intersect the element. 
% Then we split
elseif( (yy1<0.5)&&(yy2>0.5)&&(xx2<=0)&&(xx1>=-1))
    % split the integral in
    % [xx1 xx2]x[yy1 0.5] 
    % [xx1 xx2]x[0.5 yy2]
         
%    keyboard
    kk = integral_on_rectangle_wedge(intfun, xx1,xx2,yy1,0.5, kvp)+    ...
         integral_on_rectangle_wedge(intfun, xx1,xx2,0.5,yy2, kvp);   
             
                          
% The element can be shared by the region where there are the BOTTOM and 
% UPPER LINES and the region where the waveguide became TAUSCH like. In 
% this case we split the element
elseif ((xx1<0) && (xx2>0))
      
    % split the integral in
    % [xx1 0]x[yy1 yy2] 
    % [0 xx2]x[yy1 yy2]
            
    kk = integral_on_rectangle_wedge(intfun, xx1,0,yy1,yy2, kvp)+    ...
         integral_on_rectangle_wedge(intfun, 0,xx2,yy1,yy2, kvp);             


% If we are not in the previous cases, then it possible that we inteesect  
% the BOTTOM LINE:   y=-x/2


elseif( ((yy1<0.5)&&(yy2>0.5)&&(xx2<=0)) || ( (yy2<=0.5) && (xx2<=0) ))
                       
    % compute intersection with the BOTTOM LINE
    [ X, Y ]=rectangle_line_intersection2( xx1, xx2, yy1, yy2, -0.5, 0 );
    %keyboard

     % if there is no intersection
    if(isnan(Y(1)))
        % the rectangle (element) does not contain discontinuities so the 
        % function kv is a polynomail of second degree and then we can
        % perform a quadrature

        kk_val=kvp(mean([xx1,xx2]),mean([yy1,yy2]));
        w=rectangle_quadrature( intfun, xx1,xx2,yy1,yy2 );
        kk=kk_val*w;
        
    % if there is intersection    
    else
        % CASE_ 1 TRIANGLE+TRIANGLE
        if(  ismember(xx1,X) && ismember(xx2,X) &&  ismember(yy1,Y) && ismember(yy2,Y)  )
            CASE_='1 BOTTOM';
            % split the integral in the triangles defined (in counterclockwise order) by
            %
            %   FIRST TRIANGLE
            %   (xx1 yy1)  (xx2 yy1)   (xx1 yy2)
            %
            %   SECOND TRIANGLE
            %   (xx2 yy1)  (xx2 yy2)   (xx1 yy2)
            %
            %
               
            T1=[                ...
                xx1    yy1  ;   ...
                xx2    yy1  ;   ...
                xx1    yy2  ;   ...
                ];
                    
            T2=[                ...
                xx2     yy1  ;  ...
                xx2     yy2  ;  ...
                xx1     yy2  ;  ...
                ];


            % computing the integrals
            w1 = triangle_quadrature(intfun, T1(1,:), T1(2,:), T1(3,:));
            w2 = triangle_quadrature(intfun, T2(1,:), T2(2,:), T2(3,:));
            
            % computing the value of the function kvp in the middle of the
            % sub region
            Kw1_val=kvp(sum(T1(:,1))/3,sum(T1(:,2))/3); 
            Kw2_val=kvp(sum(T2(:,1))/3,sum(T2(:,2))/3); 

            % sum the results
            kk=Kw1_val*w1+Kw2_val*w2;
            
            
        % CASE_ 2 QUADRILATERAL+QUADRILATERAL
        elseif( ismember(xx1,X) && ismember(xx2,X) )
            CASE_='2 BOTTOM';
                    
            % sort to have counterclockwise order 
            Y=sort(Y);
                    
                
            % split the integral in the quadrilateral defined (in counterclockwise order) by
            %
            %   FIRST QUADRILATERAL
            %   (xx1 yy1)  (xx2 yy1)   (xx2 Y(1))    (xx1 Y(2))
            %
            %   SECOND QUADRILATERAL
            %   (xx1 yy2)  (xx1 Y(2))   (xx2 Y(1))    (xx2 yy2)
            %
            %

            Q1=[                ...
                xx1 yy1  ;      ...
                xx2 yy1  ;      ...
                xx2 Y(1) ;      ...
                xx1 Y(2) ;      ...
                ];

            Q2=[                ...
                xx1 yy2  ;      ...
                xx1 Y(2) ;      ...
                xx2 Y(1) ;      ...
                xx2 yy2  ;      ...
                ];


            % computing the integrals
            w1 = quadrilateral_quadrature(intfun, Q1(1,:), Q1(2,:), Q1(3,:), Q1(4,:) );
            w2 = quadrilateral_quadrature(intfun, Q2(1,:), Q2(2,:), Q2(3,:), Q2(4,:) );
            
            % computing the value of the function kvp in the middle of the
            % sub region
            Kw1_val=kvp(sum(Q1(:,1))/4,sum(Q1(:,2))/4); 
            Kw2_val=kvp(sum(Q2(:,1))/4,sum(Q2(:,2))/4); 
            
            % sum the results
            kk=Kw1_val*w1+Kw2_val*w2;
                                        
        % CASE_ 3 QUADRILATERAL+QUADRILATERAL         
        elseif(  ismember(yy1,Y) && ismember(yy2,Y) && ~ismember(xx1,X)  && ~ismember(xx2,X)     )
            CASE_='3 BOTTOM';
                    
            % sort to have counterclockwise order 
            X=sort(X);
                
            % split the integral in the quadrilateral defined (in counterclockwise order) by
            %
            %   FIRST QUADRILATERAL
            %   (xx1 yy1)  (X(2) yy1)   (X(1) yy2)     (xx1 yy2)
            %
            %   SECOND QUADRILATERAL
            %   (X(2) yy1)  (xx2 yy1)   (xx2 yy2)      (X(1) yy2)
            %
            %
            Q1=[                ...
                xx1  yy1 ;      ...
                X(2) yy1 ;      ...
                X(1) yy2 ;      ...
                xx1  yy2 ;      ...
                ];
            
            Q2=[
                 X(2) yy1 ;     ...
                 xx2  yy1 ;     ...
                 xx2  yy2 ;     ...
                 X(1) yy2 ;     ...
                 ];


            % computing the integrals
            w1 = quadrilateral_quadrature(intfun, Q1(1,:), Q1(2,:), Q1(3,:), Q1(4,:) );
            w2 = quadrilateral_quadrature(intfun, Q2(1,:), Q2(2,:), Q2(3,:), Q2(4,:) );
            
            % computing the value of the function kvp in the middle of the
            % sub region
            Kw1_val=kvp(sum(Q1(:,1))/4,sum(Q1(:,2))/4); 
            Kw2_val=kvp(sum(Q2(:,1))/4,sum(Q2(:,2))/4); 

            % sum the results            
            kk=Kw1_val*w1+Kw2_val*w2;
            
            
                             
        % CASE_ 4 QUADRILATERAL+TRIANGLE : intersection in top-left corner         
        elseif( ismember(xx1,X) && ismember(yy2,Y)  )
            
            % removing the corner intersection
            X=X(X~=xx1);
            Y=Y(Y~=yy2);
            
            % CASE_ 4a
            if(ismember(xx2,X))
                CASE_='4a BOTTOM';               

                % split the integrals in triangle+quadrilateral
                % (counterclockwise order)
                %
                % TRIANGLE
                % (xx1 yy2) (xx2 Y)   (xx2 yy2)
                %
                % QUADRILATERAL
                % (xx1 yy1) (xx2 yy1)   (xx2 Y)   (xx1 yy2)

                T=[             ...
                    xx1 yy2 ;   ...
                    xx2 Y   ;   ...
                    xx2 yy2 ;   ...
                   ];

                Q=[             ...
                    xx1 yy1 ;   ...
                    xx2 yy1 ;   ...
                    xx2 Y   ;   ...
                    xx1 yy2 ;   ...
                   ];


                % computing the integrals
                w1 = triangle_quadrature(intfun, T(1,:), T(2,:), T(3,:));
                w2 = quadrilateral_quadrature(intfun, Q(1,:), Q(2,:), Q(3,:), Q(4,:) );
                
                % computing the value of the function kvp in the middle of the
                % sub region

                Kw1_val=kvp(sum(T(:,1))/3,sum(T(:,2))/3); 
                Kw2_val=kvp(sum(Q(:,1))/4,sum(Q(:,2))/4); 

                % sum the results                
                kk=Kw1_val*w1+Kw2_val*w2;
                                
            % CASE_ 4b
            elseif(ismember(yy1,Y))
                CASE_='4b BOTTOM';
                
                % split the integrals in triangle+quadrilateral
                % (counterclockwise order)
                %
                % TRIANGLE
                % (xx1 yy1) (X yy1) (xx1 yy2)
                %
                % QUADRILATERAL
                % (X yy1)   (xx2 yy1)   (xx2 yy2)   (xx1 yy2)

                T=[             ...
                  xx1 yy1;      ...
                  X   yy1;      ...
                  xx1 yy2;      ...
                  ];

                Q=[             ...
                    X   yy1;    ...   
                    xx2 yy1;    ...
                    xx2 yy2;    ...
                    xx1 yy2;    ...
                   ];

                % computing the integrals
                w1 = triangle_quadrature(intfun, T(1,:), T(2,:), T(3,:));
                w2 = quadrilateral_quadrature(intfun, Q(1,:), Q(2,:), Q(3,:), Q(4,:) );
                
                % computing the value of the function kvp in the middle of the
                % sub region
                Kw1_val=kvp(sum(T(:,1))/3,sum(T(:,2))/3); 
                Kw2_val=kvp(sum(Q(:,1))/4,sum(Q(:,2))/4); 

                % sum the results
                kk=Kw1_val*w1+Kw2_val*w2;
                
                
            else
                error('Cannot happen')
                    
            end
                            
                            
        % CASE_ 5 QUADRILATERAL+TRIANGLE: intersection in bottom-right corner
        elseif( ismember(xx2,X) && ismember(yy1,Y)  )
            
            % removing the corner intersection
            X=X(X~=xx2);
            Y=Y(Y~=yy1);
            
            % CASE_ 5a
            if(ismember(yy2,Y))
                CASE_='5a BOTTOM';
                
                % split the integrals in triangle+quadrilateral
                % (counterclockwise order)
                %
                % TRIANGLE
                % (xx2 yy1) (xx2 yy2)   (X yy2)
                %
                % QUADRILATERAL
                % (xx1 yy1) (xx2 yy1)   (X yy2)   (xx1 yy2)

                T=[             ...
                   xx2 yy1;     ...
                   xx2 yy2;     ...
                   X   yy2;     ...
                   ];

                Q=[             ...
                    xx1 yy1;    ...
                    xx2 yy1;    ...
                    X   yy2;    ...
                    xx1 yy2;    ...
                    ];


                 % computing the integrals
                 w1 = triangle_quadrature(intfun, T(1,:), T(2,:), T(3,:));
                 w2 = quadrilateral_quadrature(intfun, Q(1,:), Q(2,:), Q(3,:), Q(4,:) );
                 
                 % computing the value of the function kvp in the middle of the
                 % sub region
                 Kw1_val=kvp(sum(T(:,1))/3,sum(T(:,2))/3); 
                 Kw2_val=kvp(sum(Q(:,1))/4,sum(Q(:,2))/4); 

                 kk=Kw1_val*w1+Kw2_val*w2;
                 
                                
            % CASE_ 5b                
            elseif(ismember(xx1,X))
                CASE_='5b BOTTOM';
                
                % split the integrals in triangle+quadrilateral
                % (counterclockwise order)
                %
                % TRIANGLE
                % (xx1 yy1) (xx2 yy1) (xx1 Y)
                %
                % QUADRILATERAL
                % (xx1 Y)   (xx2 yy1)   (xx2 yy2)   (xx1 yy2)

                T=[             ...
                   xx1 yy1;     ...
                   xx2 yy1;     ...
                   xx1  Y ;     ...
                   ];
                
                Q=[             ...
                    xx1 Y    ;  ...
                    xx2 yy1  ;  ...
                    xx2 yy2  ;  ...
                    xx1 yy2  ;  ...
                   ];
               
               % computing the integrals
               w1 = triangle_quadrature(intfun, T(1,:), T(2,:), T(3,:));
               w2 = quadrilateral_quadrature(intfun, Q(1,:), Q(2,:), Q(3,:), Q(4,:) );
               
               % computing the value of the function kvp in the middle of the
               % sub region
               Kw1_val=kvp(sum(T(:,1))/3,sum(T(:,2))/3); 
               Kw2_val=kvp(sum(Q(:,1))/4,sum(Q(:,2))/4); 

               % sum the results
               kk=Kw1_val*w1+Kw2_val*w2;
                                
               
            else
                error('Cannot happen')
                
            end
                            
                            
        % CASE_ 6: RECTANGLE+QUADRILATERAL+TRIANGLE           
        elseif (    ( ismember(xx1,X) && ismember(yy1,Y) )     ||     ( ismember(xx2,X) && ismember(yy2,Y) )    )
            
            % CASE_ 6a
            if(ismember(xx1,X) && ismember(yy1,Y))
                CASE_='6a BOTTOM';
                        
                % removing the intersections
                X=X(X~=xx1);
                Y=Y(Y~=yy1);
                        
                % split the integrals in triangle+quadrilateral+rectangle
                % (counterclockwise order)
                %
                % TRIANGLE
                % (xx1 yy1) (X yy1) (xx1 Y)
                %
                % QUADRILATERAL
                % (X yy1)   (xx2 yy1)   (xx2 Y)   (xx1 Y)
                %
                % RECTANGLE
                % [xx1 xx2]x[Y yy2]

                T=[             ...
                    xx1 yy1 ;   ...
                    X   yy1 ;   ...
                    xx1 Y   ;   ...
                   ];

                 Q=[            ...
                    X   yy1 ;   ...
                    xx2 yy1 ;   ...
                    xx2 Y   ;   ...
                    xx1 Y   ;   ...
                   ];

                 % computing the integrals
                 w1 = triangle_quadrature(intfun, T(1,:), T(2,:), T(3,:));
                 w2 = quadrilateral_quadrature(intfun, Q(1,:), Q(2,:), Q(3,:), Q(4,:) );
                 w3 = rectangle_quadrature( intfun, xx1,xx2,Y,yy2 );

                 % computing the value of the function kvp in the middle of the
                 % sub region
                 Kw1_val=kvp(sum(T(:,1))/3,sum(T(:,2))/3); 
                 Kw2_val=kvp(sum(Q(:,1))/4,sum(Q(:,2))/4);
                 Kw3_val=kvp(mean([xx1 xx2]),mean([Y yy2]));

                 % sum the results
                 kk=Kw1_val*w1+Kw2_val*w2+Kw3_val*w3;
                         
             % CASE_ 6b     
            elseif(ismember(xx2,X) && ismember(yy2,Y))
                CASE_='6b BOTTOM';
                        
                % removing the corner intersection
                X=X(X~=xx2);
                Y=Y(Y~=yy2);
                       
                % split the integrals in triangle+quadrilateral+rectangle
                % (counterclockwise order)
                %
                % TRIANGLE
                % (X yy2) (xx2 Y) (xx2 yy2)
                %
                % QUADRILATERAL
                % (xx1 Y)   (xx2 Y)   (X yy2)   (xx1 yy2)
                %
                % RECTANGLE
                % [xx1 xx2]x[yy1 Y]
                                       
                T=[             ...
                    X   yy2 ;   ...
                    xx2 Y   ;   ...
                    xx2 yy2 ;   ...
                    ];

                Q=[            ...
                   xx1 Y   ;   ...
                   xx2 Y   ;   ...
                   X   yy2 ;   ...
                   xx1 yy2 ;   ...
                   ];
                         
                 % computing the integrals
                 w1 = triangle_quadrature(intfun, T(1,:), T(2,:), T(3,:));
                 w2 = quadrilateral_quadrature(intfun, Q(1,:), Q(2,:), Q(3,:), Q(4,:) );
                 w3 = rectangle_quadrature( intfun, xx1,xx2,yy1,Y );
                 
                 % computing the value of the function kvp in the middle of the
                 % sub region
                 Kw1_val=kvp(sum(T(:,1))/3,sum(T(:,2))/3); 
                 Kw2_val=kvp(sum(Q(:,1))/4,sum(Q(:,2))/4);
                 Kw3_val=kvp(mean([xx1 xx2]),mean([yy1 Y]));

                 % sum the results
                 kk=Kw1_val*w1+Kw2_val*w2+Kw3_val*w3;                        
                        
                        
                        
                    
            end
            
            
            
            
            
        else
            error('Cannot happen')
                                           
        end
        
        
        
        
        
    end
            
            
            
% If we are not in the previous cases, then it possible that we inteesect  
% the UPPER LINE:   y=x/2+1
elseif((yy1>=0.5)&&(xx2<=0))
    
    % compute intersection with the UPPER LINE
    [ X, Y ]=rectangle_line_intersection2( xx1, xx2, yy1, yy2, 0.5, 1 );
    
    % if there is no intersection
    if(isnan(Y(1)))
        
        % the rectangle (element) does not contain discontinuities f the
        % function kv than we can use the previous formula that is to
        % perform the quadrature without splitting the domain since we are
        % integrating a polynomial function        

        kk_val=kvp(mean([xx1,xx2]),mean([yy1,yy2]));
        w=rectangle_quadrature( intfun, xx1,xx2,yy1,yy2 );
        kk=kk_val*w;
                
                
    % if there is intersection        
    else
        
        % CASE_ 1 TRIANGLE+TRIANGLE
        if(  ismember(xx1,X) && ismember(xx2,X) &&  ismember(yy1,Y) && ismember(yy2,Y)  )
            
            CASE_='1 UPPER';
                
            % split the integral in the triangles defined (in counterclockwise order) by
            %
            %   FIRST TRIANGLE
            %   (xx1 yy1)  (xx2 yy2)   (xx1 yy2)
            %
            %   SECOND TRIANGLE
            %   (xx1 yy1)  (xx2 yy1)   (xx2 yy2)
            %
            %
            
            T1=[                ...
                xx1 yy1     ;   ...
                xx2 yy2     ;   ...
                xx1 yy2     ;   ...
                ];
                    
            T2=[                ...
                xx1 yy1     ;   ...
                xx2 yy1     ;   ...
                xx2 yy2     ;   ...
                ];


            % computing the integrals
            w1 = triangle_quadrature(intfun, T1(1,:), T1(2,:), T1(3,:));
            w2 = triangle_quadrature(intfun, T2(1,:), T2(2,:), T2(3,:));

            % computing the value of the function kvp in the middle of the
            % sub region
            Kw1_val=kvp(sum(T1(:,1))/3,sum(T1(:,2))/3); 
            Kw2_val=kvp(sum(T2(:,1))/3,sum(T2(:,2))/3); 

            % sum the results
            kk=Kw1_val*w1+Kw2_val*w2;
%            keyboard
                    
            
        % CASE_ 2 QUADRILATERAL+QUADRILATERAL    
        elseif( ismember(xx1,X) && ismember(xx2,X) )
            CASE_='2 UPPER';
                
            % sort to have counterclockwise order 
            Y=sort(Y);
                    
                
            % split the integral in the quadrilateral defined (in counterclockwise order) by
            %
            %   FIRST QUADRILATERAL
            %   (xx1 yy1)  (xx2 yy1)   (xx2 Y(2))    (xx1 Y(1))
            %
            %   SECOND QUADRILATERAL
            %   (xx1 yy2)  (xx1 Y(1))   (xx2 Y(2))    (xx2 yy2)
            %
            %

            Q1=[                ...
                xx1 yy1  ;      ...
                xx2 yy1  ;      ...
                xx2 Y(2) ;      ...
                xx1 Y(1) ;      ...
                ];

             
            Q2=[                ...
                xx1 yy2  ;      ...
                xx1 Y(1) ;      ...
                xx2 Y(2) ;      ...
                xx2 yy2  ;      ...
                ];


            % computing the integrals
            w1 = quadrilateral_quadrature(intfun, Q1(1,:), Q1(2,:), Q1(3,:), Q1(4,:) );
            w2 = quadrilateral_quadrature(intfun, Q2(1,:), Q2(2,:), Q2(3,:), Q2(4,:) );
               
            % computing the value of the function kvp in the middle of the
            % sub region
            Kw1_val=kvp(sum(Q1(:,1))/4,sum(Q1(:,2))/4); 
            Kw2_val=kvp(sum(Q2(:,1))/4,sum(Q2(:,2))/4);
               
            % sum the results
            kk=Kw1_val*w1+Kw2_val*w2;
                                        

        % CASE_ 3 QUADRILATERAL+QUADRILATERAL                            
        elseif(  ismember(yy1,Y) && ismember(yy2,Y) &&  ~ismember(xx1,X) && ~ismember(xx2,X)   )
            CASE_='3 UPPER';
            
            % sort to have counterclockwise order 
            X=sort(X);
                
            % split the integral in the quadrilateral defined (in counterclockwise order) by
            %
            %   FIRST QUADRILATERAL
            %   (xx1 yy1)  (X(1) yy1)   (X(2) yy2)     (xx1 yy2)
            %
            %   SECOND QUADRILATERAL
            %   (X(1) yy1)  (xx2 yy1)   (xx2 yy2)      (X(2) yy2)
            %
            %
            
            Q1=[                ...
                xx1  yy1 ;      ...
                X(1) yy1 ;      ...
                X(2) yy2 ;      ...
                xx1  yy2 ;      ...
                ];
            
            Q2=[                ...
                 X(1) yy1 ;     ...
                 xx2  yy1 ;     ...
                 xx2  yy2 ;     ...
                 X(2) yy2 ;     ...
                 ];
             


             % computing the integrals
             w1 = quadrilateral_quadrature(intfun, Q1(1,:), Q1(2,:), Q1(3,:), Q1(4,:) );
             w2 = quadrilateral_quadrature(intfun, Q2(1,:), Q2(2,:), Q2(3,:), Q2(4,:) );

             % computing the value of the function kvp in the middle of the
             % sub region
             Kw1_val=kvp(sum(Q1(:,1))/4,sum(Q1(:,2))/4); 
             Kw2_val=kvp(sum(Q2(:,1))/4,sum(Q2(:,2))/4); 

             % sum the results
             kk=Kw1_val*w1+Kw2_val*w2;
                    
        % CASE_ 4 QUADRILATERAL+TRIANGLE : intersection in top-left corner            
        elseif( ismember(xx1,X) && ismember(yy1,Y)  )
            
            % removing the corner intersection
            X=X(X~=xx1);
            Y=Y(Y~=yy1);
            
            % CASE_ 4a
            if(ismember(xx2,X))
                CASE_='4a UPPER';
                
                % split the integrals in triangle+quadrilateral
                % (counterclockwise order)
                %
                % TRIANGLE
                % (xx1 yy1) (xx2 yy1)   (xx2 Y)
                %
                % QUADRILATERAL
                % (xx1 yy1) (xx2 Y)   (xx2 yy2)   (xx1 yy2)

                T=[             ...
                    xx1 yy1 ;   ...
                    xx2 yy1 ;   ...
                    xx2 Y   ;   ...
                   ];

               Q=[             ...
                   xx1 yy1 ;   ...
                   xx2 Y   ;   ...
                   xx2 yy2 ;   ...
                   xx1 yy2 ;   ...
                 ];
             
             % computing the integrals
             w1 = triangle_quadrature(intfun, T(1,:), T(2,:), T(3,:));
             w2 = quadrilateral_quadrature(intfun, Q(1,:), Q(2,:), Q(3,:), Q(4,:) );

             % computing the value of the function kvp in the middle of the
             % sub region
             Kw1_val=kvp(sum(T(:,1))/3,sum(T(:,2))/3); 
             Kw2_val=kvp(sum(Q(:,1))/4,sum(Q(:,2))/4); 

             % sum the results
             kk=Kw1_val*w1+Kw2_val*w2;
                                
                                
            % CASE_ 4b
            elseif(ismember(yy2,Y))                
                CASE_='4b UPPER';
                
                % split the integrals in triangle+quadrilateral
                % (counterclockwise order)
                %
                % TRIANGLE
                % (xx1 yy1) (X yy2) (xx1 yy2)
                %
                % QUADRILATERAL
                % (xx1 yy1)   (xx2 yy1)   (xx2 yy2)   (X yy2)

                T=[             ...
                  xx1 yy1;      ...
                  X   yy2;      ...
                  xx1 yy2;      ...
                  ];

                Q=[             ...
                    xx1 yy1;    ...   
                    xx2 yy1;    ...
                    xx2 yy2;    ...
                    X   yy2;    ...
                   ];
               
               % computing the integrals
               %keyboard
               w1 = triangle_quadrature(intfun, T(1,:), T(2,:), T(3,:));
               w2 = quadrilateral_quadrature(intfun, Q(1,:), Q(2,:), Q(3,:), Q(4,:) );
               
               % computing the value of the function kvp in the middle of the
               % sub region
               Kw1_val=kvp(sum(T(:,1))/3,sum(T(:,2))/3); 
               Kw2_val=kvp(sum(Q(:,1))/4,sum(Q(:,2))/4); 
               
               % sum the results
               kk=Kw1_val*w1+Kw2_val*w2;
                                
                            
            else
                error('Cannot happen')
                 
            end
                            
                            
        % CASE_ 5 QUADRILATERAL+TRIANGLE: intersection in bottom-right corner            
        elseif( ismember(xx2,X) && ismember(yy2,Y)  )
            
            % removing the corner intersection
            X=X(X~=xx2);
            Y=Y(Y~=yy2);
            
            % CASE_ 5a
            if(ismember(yy1,Y))
                CASE_='5a UPPER';
                
                
                % split the integrals in triangle+quadrilateral
                % (counterclockwise order)
                %
                % TRIANGLE
                % (X yy1) (xx2 yy1)   (xx2 yy2)
                %
                % QUADRILATERAL
                % (xx1 yy1) (X yy1)   (xx2 yy2)   (xx1 yy2)
                
                
                T=[             ...
                   X   yy1;     ...
                   xx2 yy1;     ...
                   xx2 yy2;     ...
                   ];
                
                
                Q=[             ...
                    xx1 yy1;    ...
                    X   yy1;    ...
                    xx2 yy2;    ...
                    xx1 yy2;    ...
                   ];
                
                
                % computing the integrals
                w1 = triangle_quadrature(intfun, T(1,:), T(2,:), T(3,:));
                w2 = quadrilateral_quadrature(intfun, Q(1,:), Q(2,:), Q(3,:), Q(4,:) );
                
                % computing the value of the function kvp in the middle of the
                % sub region
                Kw1_val=kvp(sum(T(:,1))/3,sum(T(:,2))/3); 
                Kw2_val=kvp(sum(Q(:,1))/4,sum(Q(:,2))/4); 

                % sum the results
                kk=Kw1_val*w1+Kw2_val*w2;
                                
                                
                            
            % CASE_ 5b              
            elseif(ismember(xx1,X))
                CASE_='5b UPPER';
                  
                % split the integrals in triangle+quadrilateral
                % (counterclockwise order)
                %
                % TRIANGLE
                % (xx1 Y) (xx2 yy2) (xx1 yy2)
                %
                % QUADRILATERAL
                % (xx1 yy1)   (xx2 yy1)   (xx2 yy2)   (xx1 Y)

                T=[             ...
                    xx1 Y   ;   ...
                    xx2 yy2 ;   ...
                    xx1 yy2 ;   ...
                      ];

                Q=[             ...
                    xx1 yy1 ;   ...
                    xx2 yy1 ;   ...
                    xx2 yy2 ;   ...
                    xx1 Y   ;   ...
                    ];

                % computing the integrals
                w1 = triangle_quadrature(intfun, T(1,:), T(2,:), T(3,:));
                w2 = quadrilateral_quadrature(intfun, Q(1,:), Q(2,:), Q(3,:), Q(4,:) );
                  
                % computing the value of the function kvp in the middle of the
                % sub region
                Kw1_val=kvp(sum(T(:,1))/3,sum(T(:,2))/3); 
                Kw2_val=kvp(sum(Q(:,1))/4,sum(Q(:,2))/4); 

                % sum the results
                kk=Kw1_val*w1+Kw2_val*w2;
                                
                  
            
            else
                error('Cannot happen')
                
            end
            
            
            
        % CASE_ 6: RECTANGLE+QUADRILATERAL+TRIANGLE        
        elseif ( (ismember(xx1,X) && ismember(yy2,Y)) || (ismember(xx2,X) && ismember(yy1,Y)))
            
            % CASE_ 6a
            if(ismember(xx1,X) && ismember(yy2,Y))
                CASE_='6a UPPER';
                        
                % removing the intersections
                X=X(X~=xx1);
                Y=Y(Y~=yy2);
                        
                % split the integrals in triangle+quadrilateral+rectangle
                % (counterclockwise order)
                %
                % TRIANGLE
                % (xx1 Y) (X yy2) (xx1 yy2)
                %
                % QUADRILATERAL
                % (xx1 Y)   (xx2 Y)   (xx2 yy2)   (X yy2)
                %
                % RECTANGLE
                % [xx1 xx2]x[yy1 Y]
                         
                T=[             ...
                    xx1 Y   ;   ...
                    X   yy2 ;   ...
                    xx1 yy2 ;   ...
                    ];
                
                Q=[            ...
                   xx1 Y   ;   ...
                   xx2 Y   ;   ...
                   xx2 yy2 ;   ...
                   X   yy2 ;   ...
                   ];
                              
               % computing the integrals
               w1 = triangle_quadrature(intfun, T(1,:), T(2,:), T(3,:));
               w2 = quadrilateral_quadrature(intfun, Q(1,:), Q(2,:), Q(3,:), Q(4,:) );
               w3 = rectangle_quadrature( intfun, xx1,xx2,yy1,Y );
               
              
               % computing the value of the function kvp in the middle of the
               % sub region
               Kw1_val=kvp(sum(T(:,1))/3,sum(T(:,2))/3); 
               Kw2_val=kvp(sum(Q(:,1))/4,sum(Q(:,2))/4);
               Kw3_val=kvp(mean([xx1 xx2]),mean([yy1 Y]));
               
               % sum the results
               kk=Kw1_val*w1+Kw2_val*w2+Kw3_val*w3;
                         
                    
            % CASE_ 6b        
            elseif(ismember(xx2,X) && ismember(yy1,Y))
                
                CASE_='6b UPPER';
                % removing the intersections
                X=X(X~=xx2);
                Y=Y(Y~=yy1);
                
                % split the integrals in triangle+quadrilateral+rectangle
                % (counterclockwise order)
                %
                % TRIANGLE
                % (X yy1) (xx2 yy1) (xx2 Y)
                %
                % QUADRILATERAL
                % (xx1 yy1)   (X yy1)   (xx2 Y)   (xx1 Y)
                %
                % RECTANGLE
                % [xx1 xx2]x[Y yy2]
                
               T=[             ...
                   X   yy1 ;   ...
                   xx2 yy1 ;   ...
                   xx2 Y   ;   ...
                  ];

               Q=[            ...
                  xx1 yy1 ;   ...
                  X   yy1 ;   ...
                  xx2 Y   ;   ...
                  xx1 Y   ;   ...
                  ];
                         
                
              % computing the integrals
              w1 = triangle_quadrature(intfun, T(1,:), T(2,:), T(3,:));
              w2 = quadrilateral_quadrature(intfun, Q(1,:), Q(2,:), Q(3,:), Q(4,:) );
              w3 = rectangle_quadrature( intfun, xx1,xx2,Y,yy2 );
              
              % computing the value of the function kvp in the middle of the
              % sub region
              Kw1_val=kvp(sum(T(:,1))/3,sum(T(:,2))/3); 
              Kw2_val=kvp(sum(Q(:,1))/4,sum(Q(:,2))/4);
              Kw3_val=kvp(mean([xx1 xx2]),mean([Y yy2]));
              
              % sum the results
              kk=Kw1_val*w1+Kw2_val*w2+Kw3_val*w3;                        
                        
                        
                        
                    
            end
            
            
            
            
            
        else
            error('Cannot happen')
                    

                            
                
        end
        
        
        
        
        
        
        
        
        
        
        
        
        
    end
        
             
% TAUSCH LIKE WAVEGUIDE             
elseif (xx1>=0) 
    
    % if one vertical line cut the element
    if (   (yy2<0.4) && (0.5>xx1)   &&  (0.5<xx2) )
        
        % split the integral in
        % [xx1 0.5]x[yy1 yy2] 
        % [0.5 xx2]x[yy1 yy2]
        
        Kw1_val=kvp(mean([xx1,0.5]),mean([yy1,yy2]));
        Kw2_val=kvp(mean([0.5,xx2]),mean([yy1,yy2]));
        
        w1=my_num_int( intfun, xx1, 0.5, yy1, yy2 );
        w2=my_num_int( intfun, 0.5, xx2, yy1, yy2 );
        
        kk=Kw1_val*w1+Kw2_val*w2;
        
    % if one vertical line cut the element        
    elseif (   (yy1>0.4) && (1>xx1)   &&  (1<xx2) )
        
        % split the integral in
        % [xx1 1]x[yy1 yy2] 
        % [1 xx2]x[yy1 yy2]
        
        Kw1_val=kvp(mean([xx1,1]),mean([yy1,yy2]));
        Kw2_val=kvp(mean([1,xx2]),mean([yy1,yy2]));
        
        w1=my_num_int( intfun, xx1, 1, yy1, yy2 );
        w2=my_num_int( intfun, 1, xx2, yy1, yy2 );
        
        kk=Kw1_val*w1+Kw2_val*w2;
        
    % if the orizzontal line cut the element            
    elseif (  (yy1<0.4) && (yy2>0.4)  )
        
        
        % if also one vertical line cut the element 
        if ( (0.5>xx1)   &&  (0.5<xx2) )
        
            % split the integral in
            % [xx1 0.5]x[yy1 0.4]
            % [0.5 xx2]x[yy1 0.4]
            % [xx1 0.5]x[0.4 yy2]
            % [0.5 xx2]x[0.4 yy2]

            Kw1_val=kvp(mean([xx1,0.5]),mean([yy1,0.4]));
            Kw2_val=kvp(mean([0.5,xx2]),mean([yy1,0.4]));
            Kw3_val=kvp(mean([xx1,0.5]),mean([0.4,yy2]));
            Kw4_val=kvp(mean([0.5,xx2]),mean([0.4,yy2]));
            
            w1=my_num_int( intfun, xx1, 0.5, yy1, 0.4 );
            w2=my_num_int( intfun, 0.5, xx2, yy1, 0.4 );
            w3=my_num_int( intfun, xx1, 0.5, 0.4, yy2 );
            w4=my_num_int( intfun, 0.5, xx2, 0.4, yy2 );
            
            kk=Kw1_val*w1+Kw2_val*w2+Kw3_val*w3+Kw4_val*w4;

        % if also one vertical line cut the element         
        elseif ( (1>xx1)   &&  (1<xx2) )
                      
            % split the integral in
            % [xx1 1]x[yy1 0.4]
            % [1 xx2]x[yy1 0.4]
            % [xx1 1]x[0.4 yy2]
            % [1 xx2]x[0.4 yy2]
            
            Kw1_val=kvp(mean([xx1,1]),mean([yy1,0.4]));
            Kw2_val=kvp(mean([1,xx2]),mean([yy1,0.4]));
            Kw3_val=kvp(mean([xx1,1]),mean([0.4,yy2]));
            Kw4_val=kvp(mean([1,xx2]),mean([0.4,yy2]));
            
            w1=my_num_int( intfun, xx1, 1, yy1, 0.4 );
            w2=my_num_int( intfun, 1, xx2, yy1, 0.4 );
            w3=my_num_int( intfun, xx1, 1, 0.4, yy2 );
            w4=my_num_int( intfun, 1, xx2, 0.4, yy2 );
            
            kk=Kw1_val*w1+Kw2_val*w2+Kw3_val*w3+Kw4_val*w4;
            
        % if no other discontinuitie lines cut the element         
        else
        
            % split the integral in
            % [xx1 xx2]x[yy1 0.4]
            % [xx1 xx2]x[0.4 yy2]
            
            Kw1_val=kvp(mean([xx1,xx2]),mean([yy1,0.4]));
            Kw2_val=kvp(mean([xx1,xx2]),mean([0.4,yy2]));
        
            w1=my_num_int( intfun, xx1, xx2, yy1, 0.4 );
            w2=my_num_int( intfun, xx1, xx2, 0.4, yy2 );
            
            kk=Kw1_val*w1+Kw2_val*w2;

        
        end
                
    else
        
        % the rectangle (element) does not contain discontinuities f the
        % function kv than we can use the previous formula that is to
        % perform the quadrature without splitting the domain since we are
        % integrating a polynomial function        

        kk_val=kvp(mean([xx1,xx2]),mean([yy1,yy2]));
        w=rectangle_quadrature( intfun, xx1,xx2,yy1,yy2 );
        kk=kk_val*w;
        

    
    end
    
    
else
    
        % the rectangle (element) does not contain discontinuities f the
        % function kv than we can use the previous formula that is to
        % perform the quadrature without splitting the domain since we are
        % integrating a polynomial function        

        kk_val=kvp(mean([xx1,xx2]),mean([yy1,yy2]));
        w=rectangle_quadrature( intfun, xx1,xx2,yy1,yy2 );
        kk=kk_val*w;
        
    
        
        
end

%keyboard
%CASE_

end



function res = rectangle_quadrature( F, xmin,xmax,ymin,ymax )
%SQUARE_QUADRATURE  Compute the quadrature of F
%   The quadrature is of degree 3 that is the result is exact for
%   polynomails of degree less or equal than 3
%
% INPUT
% F is the polynomial of degree 3
% the quadrature is computed in [xmin, xmax]x[ymin, ymax]
%
%       (xmin, ymax)                    (xmax,ymax)
%             ______________________________
%            |                             |
%            |                             |
%            |                             |
%            |_____________________________|
%       (xmin.ymin)                     (xmax,ymin)
%
%
%
% OUTPUT
% res is the result of the quadrature
%
% EXAMPLE
% integrate F in the quadrilateral defined by
% 
% F = @(x,y) x.*y+y+1;
% Matlab_res  =   quad2d( F , -pi, pi, -1, sqrt(2)) 
% My_result   =   rectangle_quadrature(F,-pi, pi, -1,sqrt(2) )




% change of variables
Nphi = @(t) ((xmin+xmax)/2)+t*((xmax-xmin)/2);
Npsi = @(s) ((ymin+ymax)/2)+s*((ymax-ymin)/2);

FF = @(t,s) F(Nphi(t),Npsi(s));




% formula 1, degree 5
% P=sqrt(3/5);
% 
% W1=64/81;
% W2=25/81;
% W3=40/81;
% 
% 
% res= W2*FF(-P,-P)   +W3*FF(0,-P)    +W2*FF(P,-P) + ...
%      W3*FF(-P,0)    +W1*FF(0,0)     +W3*FF(P,0)  + ...
%      W2*FF(-P,P)    +W3*FF(0,P)     +W2*FF(P,P);     






% formula 1, degree 5
P=sqrt(1/3);
res= FF(P,P)+FF(-P,P)+FF(P,-P)+FF(-P,-P);

res=res*(ymax-ymin)*(xmax-xmin);
res=res/4;


end




function res = triangle_quadrature(F, Q1, Q2, Q3)
%QUADRILATERAL_QUADRATURE Compute the quadrature of F
%
%   The quadrature is of degree 2 that is the result is exact for
%   polynomails of degree less or equal than 2
%
% INPUT
% F is the polynomial of degree 2
% Q1, Q2, Q3 are the points that define the triangle. They must be
% setted in such way that have to follow the counterclockwise. That is
%
%               Q2
%               /\
%              /  \
%             /    \
%            /      \
%           /        \
%          /__________\
%         Q3           Q1
%
% OUTPUT
% res is the result of the quadrature
%
% EXAMPLE
% F = @(x,y) x.*x+y+1;
% integrate F in the quadrilateral defined by
% (2,0) (0,1) (-1,0)
% ymax = @(x) (x<=0).*(1+x)   + (x>0).*(1-x/2);
% Matlab_res  =   integral2( F , -1, 2, 0,ymax) 
% My_result   =   triangle_quadrature(F, [2 0], [0 1], [-1 0])


% NODAL SHAPE FUNCTIONS
N1 = @(xi,ni)   -xi-ni+1;
N2 = @(xi,ni)   xi;
N3 = @(xi,ni)   ni;


% change of coordinates to have the canonical square [-1 1]x[-1 1]
P = @(xi,ni)    N1(xi,ni)*Q1(1) +    N2(xi,ni)*Q2(1) +   N3(xi,ni)*Q3(1);
Q = @(xi,ni)    N1(xi,ni)*Q1(2) +    N2(xi,ni)*Q2(2) +   N3(xi,ni)*Q3(2);


% Jacobian of the change of variables (is constant!)
J =     Q1(1) * ( Q2(2) - Q3(2) ) +...
        Q2(1) * ( Q3(2) - Q1(2) ) +...
        Q3(1) * ( Q1(2) - Q2(2) );

J = abs(J);    
    
% NEW FUNCTION THAT WILL BE INTEGRATED IN THE CANONICAL SQUARE
FF = @(xi,ni)   F( P(xi,ni), Q(xi,ni) ) * J;

C1=1/6;     C2=2/3;
res =  ( FF(C1,C1)   +   FF(C2,C1)   +   FF(C1,C2) )/6;
%res= (-27/96)*FF(1/3,1/5)+(25/96)*( FF(1/5,1/5) + FF(1/5,3/5) + FF(3/5,1/5) );





end

function res = quadrilateral_quadrature(F, Q1, Q2, Q3, Q4 )
%QUADRILATERAL_QUADRATURE Compute the quadrature of F
%
%   DO NOT USE IF YOU ARE INTEGRATING ON A RECTANGLE!
%   USE INSTEAD rectangle_quadrature THAT IS FASTER
%
%   The quadrature is of degree 2 that is the result is exact for
%   polynomails of degree less or equal than 2
%
% INPUT
% F is the polynomial of degree 2
% Q1, Q2, Q3, Q4 are the points that define the quadrilateral. They must be
% setted in such way that have to follow the counterclockwise. That is
%
%   Q4                        Q3
%   ___________________________
%   \                         |
%    \                        |
%     \                       |
%      \______________________|
%       Q1                    Q2
%
% OUTPUT
% res is the result of the quadrature
%
% EXAMPLE
% integrate F in the quadrilateral defined by
% (0,0) (1,0) (0,1) (1,2)
% F = @(x,y) x.*y+y+1;
% Matlab_res  =   integral2( F , 0, 1, 0,@(x) x+1) 
% My_result   =   quadrilateral_quadrature(F, [0 0], [1 0], [1 2], [0 1] )


% NODAL SHAPE FUNCTIONS
N1 = @(xi,ni)   1/4*(1-xi)*(1-ni);
N2 = @(xi,ni)   1/4*(1+xi)*(1-ni);
N3 = @(xi,ni)   1/4*(1+xi)*(1+ni);
N4 = @(xi,ni)   1/4*(1-xi)*(1+ni);


% change of coordinates to have the canonical square [-1 1]x[-1 1]
P = @(xi,ni)    N1(xi,ni)*Q1(1) +    N2(xi,ni)*Q2(1) +   N3(xi,ni)*Q3(1) +   N4(xi,ni)*Q4(1);
Q = @(xi,ni)    N1(xi,ni)*Q1(2) +    N2(xi,ni)*Q2(2) +   N3(xi,ni)*Q3(2) +   N4(xi,ni)*Q4(2);


% Jacobian of the change of variables

% derivatives of the nodal shape functions
N1xi = @(xi,ni)   -1/4*(1-ni);      N1ni = @(xi,ni)   -1/4*(1-xi);
N2xi = @(xi,ni)    1/4*(1-ni);      N2ni = @(xi,ni)   -1/4*(1+xi);
N3xi = @(xi,ni)    1/4*(1+ni);      N3ni = @(xi,ni)    1/4*(1+xi);
N4xi = @(xi,ni)   -1/4*(1+ni);      N4ni = @(xi,ni)    1/4*(1-xi);

Pxi = @(xi,ni)    N1xi(xi,ni)*Q1(1) +    N2xi(xi,ni)*Q2(1) +   N3xi(xi,ni)*Q3(1) +   N4xi(xi,ni)*Q4(1);
Qxi = @(xi,ni)    N1xi(xi,ni)*Q1(2) +    N2xi(xi,ni)*Q2(2) +   N3xi(xi,ni)*Q3(2) +   N4xi(xi,ni)*Q4(2);
Pni = @(xi,ni)    N1ni(xi,ni)*Q1(1) +    N2ni(xi,ni)*Q2(1) +   N3ni(xi,ni)*Q3(1) +   N4ni(xi,ni)*Q4(1);
Qni = @(xi,ni)    N1ni(xi,ni)*Q1(2) +    N2ni(xi,ni)*Q2(2) +   N3ni(xi,ni)*Q3(2) +   N4ni(xi,ni)*Q4(2);

% Jacobian
J = @(xi,ni) abs(Pxi(xi,ni)*Qni(xi,ni) - Qxi(xi,ni)*Pni(xi,ni));

% NEW FUNCTION THAT WILL BE INTEGRATED IN THE CANONICAL SQUARE
FF = @(xi,ni)   F( P(xi,ni), Q(xi,ni) ) * J(xi,ni);

% notice that we are using a quadrature formula of degree 5 since J(xi,ni)
% is (can be...) a polynomial of degree 2 and F( P(xi,ni), Q(xi,ni) )
% is a polynomial of degree 2. than in total we have a polynomial of degree 
% 4. So the idea is that we can use the quadrature formulas in the
% canonical square also for a general quadrilateral but the degree of the
% polynomial increase.

% degree 5 quadrature
C=sqrt(3/5);
 
W1=64/81;
W2=25/81;
W3=40/81;
 
 
res= W2*FF(-C,-C)   +W3*FF(0,-C)    +W2*FF(C,-C) + ...
     W3*FF(-C,0)    +W1*FF(0,0)     +W3*FF(C,0)  + ...
     W2*FF(-C,C)    +W3*FF(0,C)     +W2*FF(C,C);     







end













function out=range_intersection2(int1,int2)
% returns the intersection of the two intervals int1(1:2) int2(1:2)
%int1=sort(int1);    int2=sort(int2); % not needed for our case
    if (int1(2)<int2(1)  || int2(2)<int1(1))
        out=zeros(1,0);
    else
        ii=[int1(:);int2(:)];
        ii=sortrows(ii);
        out=ii(2:3)';
    end
end   

function [ X, Y ] = rectangle_line_intersection2( xx1, xx2, yy1, yy2, m, c )
%RECTANGLE_LINE_INTERSECTION Compute the intersection between a line and a
%rectangle
%   
%   INPUT
%   the rectangle is [xx1, xx2] x [yy1, yy2]
%   the line that we want to intersect is y=m*x+c where m is not zero
%
%   OUTPUT
%   the intersection points are 
%   P1=( X(1),Y(1) )
%   P2=( X(2),Y(2) )
%
%   it is possible that P1 and P2 are NaN, it means that there is not
%   intersection between the rectangular and the line or the line is
%   tangent (we are not interested in this case)
%
%   EXAMPLES
%
%   Intersection between y=x/2 and [1 2]x[0 1]
%   [ X, Y ] = rectangle_line_intersection2( 1,2,0,1,1/2,0 ); [X Y]
%   the intersections must be (1,1/2) and (2,1)
%
%   Intersection between y=-x/2+1 and [1 2]x[0 1]   
%   [ X, Y ] = rectangle_line_intersection2( 1,2,0,1,-1/2,1 ); [X Y]
%   the intersections must be (1,1/2) and (2,0)
%
%   Intersection between y=x/2+1/2 and [0 2]x[-1 1]   
%   [ X, Y ] = rectangle_line_intersection2( 0,2,-1,1,1/2,1/2 ); [X Y]
%   the intersections must be (0,1/2) and (1,1)

% Note m\neq 0
         
   
   Z=[xx1, m*xx1+c
   xx2, m*xx2+c
   (yy1-c)/m ,yy1
   (yy2-c)/m ,yy2];
    tol=eps*10;
    II1=(Z(:,1)>=xx1-tol) & (Z(:,1)<=xx2+tol);
    II2=(Z(:,2)>=yy1-tol) & (Z(:,2)<=yy2+tol);
    
    Z=Z(II1&II2 ,:);
    if (size(Z,1)>2) % exceptional case
        Z2=Z(1,:);
        if (abs(Z(2,1)- Z2(1,1))<eps*10)
            Z2=[Z2;Z(3,:)];
        else
            Z2=[Z2;Z(2,:)];
        end
        Z=Z2;
    end
    if (size(Z,1)==0) % No intersection. Return NaNs
       Z=NaN*zeros(2,2); 
    end
    if (norm(Z(1,:)-Z(2,:))<eps*10) % tangent interpreted as no intersection
        Z=NaN(2,2);
    end
    X=Z(:,1);
    Y=Z(:,2);
    
    
    % plot
 %   close all
    % rectangle
 %   plot([xx1 xx2],[yy1 yy1],'-');  hold on
 %   plot([xx1 xx2],[yy2 yy2],'-');
 %   plot([xx1 xx1],[yy1 yy2],'-');
 %   plot([xx2 xx2],[yy1 yy2],'-');

    % line 
 %   plot([xx1 xx2],[xx1*m+c xx2*m+c],'--r');
    
    % points
 %   plot(X(1),Y(1),'o');
 %   plot(X(2),Y(2),'o');

 %   d=(xx2-xx1)*0.1;
 %   axis([xx1-d xx2+d yy1-d yy2+d]);
    
%    pause
    
    
end


function  coeff  = coeff_B( i,j,i2,j2 )
%COEFF_COMPUTE_B_MATRIX compute implicitly the elements of the B matrix
%   Compute implicitly the elements of the B matrix, that is
%   the integral of phi_(i,j) aganist phi_(i2,j2) in the integer domain.

if(i==i2)&&(j==j2)
    coeff=16;
elseif ((i==i2)||(j==j2))
    coeff=4;
else
    coeff=1;
end

end


function  coeff  = coeff_integral( i,j,i2,j2 )
%COEFF_COMPUTE_B_MATRIX compute implicitly the integral of basis function
%   Compute implicitly the integral of the basis function phi_(i,j) aganist
%   phi_(i2,j2) in the square pointed in (i,j)


if ((i==i2)&&(j==j2))
    coeff=4;
elseif((i==i2)||(j==j2))
    coeff=1;
else
    coeff=1/4;
end

end


